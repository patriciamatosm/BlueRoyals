package es.uah.chats.chats;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChatsApplicationTests {

	@Test
	void contextLoads() {
	}

}
